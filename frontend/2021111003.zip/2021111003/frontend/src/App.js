import "./App.css";
import SignInUp from "./Auth/signin";
import Profile from "./Profile/profile";

function Layout() {
    let alpha = <Profile />;
    let beta = <SignInUp />;

    if (localStorage.getItem("sign_in_status") === "true") {
        return alpha;
    } else {
        return beta;
    }
}

export default Layout;
