# DASS Assignment 1 Phase 1

## Harshavardhan P

## 2021111003

## Netlify deplyment link

https://greddiitv1.netlify.app/

## Github repo link

https://github.com/Harshavardhan-Pandurangan/DASS-Assign1

## UI and styling

Used Material UI for styling and components. Used react-router-dom for routing.
Need to install material-ui and react-router-dom using npm install.
